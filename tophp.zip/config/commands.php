<?php

return [
    'server' => [
        '--port',
        '-h'
    ],
    'migrate' => [
        '--table'
    ]
];