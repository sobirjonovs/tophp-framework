<?php


namespace App\Models;

/**
 * @method static where(int[] $array)
 */
class User extends Model
{

}